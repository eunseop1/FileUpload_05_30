package kr.human.mybatis;

import java.io.File;

public class Test {
	public static void main(String[] args) {
		System.out.println(File.separator);
		System.out.println(File.pathSeparator);
		System.out.println("C:\\Users\\human\\Pictures\\2.png".lastIndexOf(File.separator ));
		System.out.println("2.png".lastIndexOf(File.separator ));
	}
}
